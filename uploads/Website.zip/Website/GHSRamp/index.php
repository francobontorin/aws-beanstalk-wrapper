<?php 

    // First we execute our common code to connection to the database and start the session 
    require("common.php"); 

    // At the top of the page we check to see whether the user is logged in or not 
    if(empty($_SESSION['user'])) 
    { 
        // If they are not, we redirect them to the login page. 
        header("Location: login.php"); 

        // Remember that this die statement is absolutely critical.  Without it, 
        // people can view your members-only content without logging in. 
        die("Redirecting to login.php"); 
    } 

    // Everything below this point in the file is secured by the login system 

    // We can display the user's username to them by reading it from the session array.  Remember that because 
    // a username is user submitted content we must use htmlentities on it before displaying it to the user. 
?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
	<title>Ground Handling Status - CHC Helicopters Netherlands BV</title>
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	<style type='text/css'>
		body {font-family:arial;font-size:11pt;padding:0;margin:0;}
		a {color: #0000FF}
		a:hover {text-decoration:underline}
		table {border-collapse:collapse;table-layout:fixed}
		.lastupdate {color:gray;font-size:8pt;padding-top:5px}
		.updatefreq {color:gray;font-size:8pt;padding-top:5px}
		td {border-left:1px solid #D0D7E5;
		    border-right:1px solid #D0D7E5;
		    border-top:1px solid #D0D7E5;
		    border-bottom:1px solid #D0D7E5}
		.t {font-family:Calibri;font-size:24pt;font-weight:bold;text-align:center;vertical-align:middle}
		.r1 {font-size:36pt}
		.c1_1 {border-top:1px solid #000000;border-left:1px solid #000000}
		.c1_4 {color:#F04F23;border-top:1px solid #000000}
		.c1_11 {font-size:20pt;vertical-align:bottom;border-top:1px solid #000000}
		.c1_12 {color:#FFFFFF;font-size:20pt;vertical-align:bottom}
		.c1_13 {font-size:11pt;font-weight:normal;vertical-align:bottom}
		.c1_15 {font-size:24pt;border-right:1px solid #000000}
		.c2_15 {border-right:1px solid #000000}
		.r3 {font-size:20pt}
		.r4 {background-color:#F04F23}
		.c4_1 {border-left:1px solid #000000}
		.c4_11 {color:#FFFFFF;font-size:8pt;font-weight:normal}
		.c7_1 {font-size:28pt;border-top:1px solid #000000;border-left:1px solid #000000}
		.c7_2 {color:#FFFFFF;border-top:1px solid #000000}
		.c7_4 {border-top:1px solid #000000}
		.c7_10 {color:#FF0000;background-color:#FF0000;border-top:1px solid #000000}
		.c7_12 {color:#FF0000;background-color:#FF0000;border-top:1px solid #000000;border-right:1px solid #000000}
		.c8_1 {font-size:28pt;border-left:1px solid #000000}
		.c8_2 {color:#FFFFFF}
		.c8_10 {color:#FF0000;background-color:#FF0000}
		.c8_12 {color:#FF0000;background-color:#FF0000;border-right:1px solid #000000}
	</style>
</head>
<body>
	<div class='updatefreq'>
	Update Frequency
	<select id='frequency' class='updatefreq' onChange='newfrequency()'>
	  <option value='1'>1 sec</option>
	  <option value='2'selected>2 sec</option>
	  <option value='5'>5 sec</option>
	  <option value='10'>10 sec</option>
	  <option value='30'>30 sec</option>
	  <option value='60'>1 min</option>
	  <option value='300'>5 min</option>
	  <option value='600'>10 min</option>
	</select></div>
	<script>
	function createCookie(name,value) {
	    var expires = '';
	    document.cookie = name+'='+value+expires+'; path=/';
	}
	function readCookie(name) {
	    var nameEQ = name + '=';
	    var ca = document.cookie.split(';');
	    for(var i=0;i < ca.length;i++) {
	        var c = ca[i];
	        while (c.charAt(0)==' ') c = c.substring(1,c.length);
	        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
	    }
	    return null;
	}
	// Javascript's IsNumeric is not reliable.
	// Amongst others:
	//    IsNumeric(' ') == true;
	// Take a look at http://stackoverflow.com/questions/18082/validate-numbers-in-javascript-isnumeric
	function isNumber(n) {
	   return !isNaN(parseFloat(n)) && isFinite(n);
	}
	function newfrequency() {
	    var frequency=document.getElementById('frequency').value;
	    if (!isNumber(frequency)) {
	        frequency=60;
	    }
	    frequency = parseInt(frequency);
	    createCookie('frequency',frequency);
	    createCookie('delay',frequency); // display correct delay first time round
	    location.reload(true);
	}
	function getfrequency() {
	    var f = readCookie('frequency');
	    if (!isNumber(f))
	        f = 60
	    else
	        f = parseInt(f);
	    return f;
	}
	function getdelay() {
	    var d = readCookie('delay');
	    if (!isNumber(d))
	        d = getfrequency()
	    else
	        d = parseInt(d);
	    return d;
	}
	function beginrefresh(){
	    var curtime;
	    var curmin;
	    var cursec;
	    var frequency = getfrequency();
	    var delay = getdelay();
	    if (delay <= 0) {
	        delay=getfrequency();
	        createCookie('delay',delay);
	        location.reload(true);
	    } else {
	        curmin=Math.floor(delay / 60);
	        cursec=delay % 60;
	        if (curmin!=0)
	            curtime='Refresh in '+curmin+' minutes and '+cursec+' seconds.'
	        else
	            curtime='Refresh in '+cursec+' seconds.'
	        delay -= 5;
	        delay = 5 * Math.floor(delay / 5); // Round to nearest 5
	        window.status=curtime;
	        createCookie('delay',delay);
	        var delayidx = 1;
	        switch (frequency) {
	            case 1:
	                delayidx=0;
	                break;
	            case 2:
	                delayidx=1;
	                break;
	            case 5:
	                delayidx=2;
	                break;
	            case 10:
	                delayidx=3;
	                break;
	            case 30:
	                delayidx=4;
	                break;
	            case 60:
	                delayidx=5;
	                break;
	            case 300:
	                delayidx=6;
	                break;
	            case 600:
	                delayidx=7;
	                break;
	        }
	        document.getElementById('frequency').selectedIndex=delayidx;
	        setTimeout('beginrefresh()',5000);
	    }
	}
	window.onload = beginrefresh
	</script>
<table class='t'>
	<tr style='height:24px' class='r1'>
		<td rowspan='3' colspan='3' class='c1_1'></td>
		<td rowspan='3' colspan='7' class='c1_4'>
			Ground Handling Status
		</td>
		<td rowspan='2' class='c1_11' style='width:143px'>
			Last Update:
		</td>
		<td rowspan='3' class='c1_12' style='width:143px'>
			<a href="logout.php">Logout</a>
		</td>
		<td rowspan='3' colspan='2' class='c1_13'></td>
		<td class='c1_15' style='width:172px'></td>
	</tr>
	<tr style='height:24px'>
		<td class='c2_15' style='width:172px'></td>
	</tr>
	<tr style='height:24px' class='r3'>
		<td style='width:143px'>
			06:23:45
		</td>
		<td class='c1_15' style='width:172px'></td>
	</tr>
	<tr style='height:11px' class='r4'>
		<td colspan='10' class='c4_1'></td>
		<td class='c4_11' style='width:143px'></td>
		<td class='c4_11' style='width:143px'></td>
		<td colspan='2'></td>
		<td class='c2_15' style='width:172px'></td>
	</tr>
	<tr style='height:31px'>
		<td class='c4_1' style='width:55px'></td>
		<td style='width:73px'>
			SAR
		</td>
		<td style='width:66px'>
			CHG
		</td>
		<td style='width:160px'>
			REG
		</td>
		<td style='width:213px'>
			Customer
		</td>
		<td style='width:186px'>
			Fuel Order
		</td>
		<td style='width:143px'>
			ETD
		</td>
		<td style='width:143px'>
			Spot
		</td>
		<td style='width:143px'>
			Fueled
		</td>
		<td style='width:143px'>
			Loaded
		</td>
		<td style='width:143px'>
			LifeJackets
		</td>
		<td class='c4_1' style='width:143px'>
			Ramp
		</td>
		<td style='width:143px'>
			Ramp
		</td>
		<td class='c2_15' style='width:172px'>
			Ramp
		</td>
	</tr>
	<tr style='height:0px'>
	</tr>
	<tr style='height:31px'>
		<td class='c7_1' style='width:55px'>
			1
		</td>
		<td class='c7_2' style='width:73px'>
			0
		</td>
		<td class='c7_2' style='width:66px'>
			0
		</td>
		<td class='c7_4' style='width:160px'>
			PH-EUE
		</td>
		<td class='c7_4' style='width:213px'>
			CHC
		</td>
		<td class='c7_4' style='width:186px'></td>
		<td class='c7_4' style='width:143px'>
			7:00
		</td>
		<td class='c7_4' style='width:143px'>
			10
		</td>
		<td class='c7_10' style='width:143px'>
			0
		</td>
		<td class='c7_10' style='width:143px'>
			0
		</td>
		<td class='c7_12' style='width:143px'>
			0
		</td>
		<td class='c4_1' style='width:143px'>
			<a href='mailto:chcoperationsdhr@chc.ca?subject=GroundHandling%20PH-EUE%20CHC%20Fueled&body=PH-EUE;CHC;Fueled;'>Fueled</a>
		</td>
		<td style='width:143px'>
			<a href='mailto:chcoperationsdhr@chc.ca?subject=GroundHandling%20PH-EUE%20CHC%20Loaded&body=PH-EUE;CHC;Loaded;'>Loaded</a>
		</td>
		<td class='c2_15' style='width:172px'>
			<a href='mailto:chcoperationsdhr@chc.ca?subject=GroundHandling%20PH-EUE%20CHC%20LJ Loaded&body=PH-EUE;CHC;LJ Loaded;'>LJ Loaded</a>
		</td>
	</tr>
	<tr style='height:31px'>
		<td class='c8_1' style='width:55px'>
			2
		</td>
		<td class='c8_2' style='width:73px'>
			0
		</td>
		<td class='c8_2' style='width:66px'>
			0
		</td>
		<td style='width:160px'>
			PH-EUJ
		</td>
		<td style='width:213px'>
			CHC
		</td>
		<td style='width:186px'>
			900
		</td>
		<td style='width:143px'>
			7:00
		</td>
		<td style='width:143px'>
			7
		</td>
		<td class='c8_10' style='width:143px'>
			0
		</td>
		<td class='c8_10' style='width:143px'>
			0
		</td>
		<td class='c8_12' style='width:143px'>
			0
		</td>
		<td class='c4_1' style='width:143px'>
			<a href='mailto:chcoperationsdhr@chc.ca?subject=GroundHandling%20PH-EUJ%20CHC%20Fueled&body=PH-EUJ;CHC;Fueled;'>Fueled</a>
		</td>
		<td style='width:143px'>
			<a href='mailto:chcoperationsdhr@chc.ca?subject=GroundHandling%20PH-EUJ%20CHC%20Loaded&body=PH-EUJ;CHC;Loaded;'>Loaded</a>
		</td>
		<td class='c2_15' style='width:172px'>
			<a href='mailto:chcoperationsdhr@chc.ca?subject=GroundHandling%20PH-EUJ%20CHC%20LJ Loaded&body=PH-EUJ;CHC;LJ Loaded;'>LJ Loaded</a>
		</td>
	</tr>
	<tr style='height:31px'>
		<td class='c8_1' style='width:55px'>
			3
		</td>
		<td class='c8_2' style='width:73px'>
			0
		</td>
		<td class='c8_2' style='width:66px'>
			0
		</td>
		<td style='width:160px'>
			PH-SHP
		</td>
		<td style='width:213px'>
			CHC
		</td>
		<td style='width:186px'></td>
		<td style='width:143px'></td>
		<td style='width:143px'>
			8
		</td>
		<td class='c8_10' style='width:143px'>
			0
		</td>
		<td class='c8_10' style='width:143px'>
			0
		</td>
		<td class='c8_12' style='width:143px'>
			0
		</td>
		<td class='c4_1' style='width:143px'>
			<a href='mailto:chcoperationsdhr@chc.ca?subject=GroundHandling%20PH-SHP%20CHC%20Fueled&body=PH-SHP;CHC;Fueled;'>Fueled</a>
		</td>
		<td style='width:143px'>
			<a href='mailto:chcoperationsdhr@chc.ca?subject=GroundHandling%20PH-SHP%20CHC%20Loaded&body=PH-SHP;CHC;Loaded;'>Loaded</a>
		</td>
		<td class='c2_15' style='width:172px'>
			<a href='mailto:chcoperationsdhr@chc.ca?subject=GroundHandling%20PH-SHP%20CHC%20LJ Loaded&body=PH-SHP;CHC;LJ Loaded;'>LJ Loaded</a>
		</td>
	</tr>
	<tr style='height:31px'>
		<td class='c8_1' style='width:55px'>
			4
		</td>
		<td class='c8_2' style='width:73px'>
			0
		</td>
		<td class='c8_2' style='width:66px'>
			0
		</td>
		<td style='width:160px'>
			G-SNSH
		</td>
		<td style='width:213px'>
			CHC
		</td>
		<td style='width:186px'></td>
		<td style='width:143px'></td>
		<td style='width:143px'>
			9
		</td>
		<td class='c8_10' style='width:143px'>
			0
		</td>
		<td class='c8_10' style='width:143px'>
			0
		</td>
		<td class='c8_12' style='width:143px'>
			0
		</td>
		<td class='c4_1' style='width:143px'>
			<a href='mailto:chcoperationsdhr@chc.ca?subject=GroundHandling%20G-SNSH%20CHC%20Fueled&body=G-SNSH;CHC;Fueled;'>Fueled</a>
		</td>
		<td style='width:143px'>
			<a href='mailto:chcoperationsdhr@chc.ca?subject=GroundHandling%20G-SNSH%20CHC%20Loaded&body=G-SNSH;CHC;Loaded;'>Loaded</a>
		</td>
		<td class='c2_15' style='width:172px'>
			<a href='mailto:chcoperationsdhr@chc.ca?subject=GroundHandling%20G-SNSH%20CHC%20LJ Loaded&body=G-SNSH;CHC;LJ Loaded;'>LJ Loaded</a>
		</td>
	</tr>
	<tr style='height:31px'>
		<td class='c8_1' style='width:55px'>
			5
		</td>
		<td class='c8_2' style='width:73px'></td>
		<td class='c8_2' style='width:66px'></td>
		<td style='width:160px'></td>
		<td style='width:213px'></td>
		<td style='width:186px'></td>
		<td style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c4_1' style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c2_15' style='width:172px'></td>
	</tr>
	<tr style='height:31px'>
		<td class='c8_1' style='width:55px'>
			6
		</td>
		<td class='c8_2' style='width:73px'></td>
		<td class='c8_2' style='width:66px'></td>
		<td style='width:160px'></td>
		<td style='width:213px'></td>
		<td style='width:186px'></td>
		<td style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c4_1' style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c2_15' style='width:172px'></td>
	</tr>
	<tr style='height:31px'>
		<td class='c8_1' style='width:55px'>
			7
		</td>
		<td class='c8_2' style='width:73px'></td>
		<td class='c8_2' style='width:66px'></td>
		<td style='width:160px'></td>
		<td style='width:213px'></td>
		<td style='width:186px'></td>
		<td style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c4_1' style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c2_15' style='width:172px'></td>
	</tr>
	<tr style='height:31px'>
		<td class='c8_1' style='width:55px'>
			8
		</td>
		<td class='c8_2' style='width:73px'></td>
		<td class='c8_2' style='width:66px'></td>
		<td style='width:160px'></td>
		<td style='width:213px'></td>
		<td style='width:186px'></td>
		<td style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c4_1' style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c2_15' style='width:172px'></td>
	</tr>
	<tr style='height:31px'>
		<td class='c8_1' style='width:55px'>
			9
		</td>
		<td class='c8_2' style='width:73px'></td>
		<td class='c8_2' style='width:66px'></td>
		<td style='width:160px'></td>
		<td style='width:213px'></td>
		<td style='width:186px'></td>
		<td style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c4_1' style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c2_15' style='width:172px'></td>
	</tr>
	<tr style='height:31px'>
		<td class='c8_1' style='width:55px'>
			10
		</td>
		<td class='c8_2' style='width:73px'></td>
		<td class='c8_2' style='width:66px'></td>
		<td style='width:160px'></td>
		<td style='width:213px'></td>
		<td style='width:186px'></td>
		<td style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c4_1' style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c2_15' style='width:172px'></td>
	</tr>
	<tr style='height:31px'>
		<td class='c8_1' style='width:55px'>
			11
		</td>
		<td class='c8_2' style='width:73px'></td>
		<td class='c8_2' style='width:66px'></td>
		<td style='width:160px'></td>
		<td style='width:213px'></td>
		<td style='width:186px'></td>
		<td style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c4_1' style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c2_15' style='width:172px'></td>
	</tr>
	<tr style='height:31px'>
		<td class='c8_1' style='width:55px'>
			12
		</td>
		<td class='c8_2' style='width:73px'></td>
		<td class='c8_2' style='width:66px'></td>
		<td style='width:160px'></td>
		<td style='width:213px'></td>
		<td style='width:186px'></td>
		<td style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c4_1' style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c2_15' style='width:172px'></td>
	</tr>
	<tr style='height:31px'>
		<td class='c8_1' style='width:55px'>
			13
		</td>
		<td class='c8_2' style='width:73px'></td>
		<td class='c8_2' style='width:66px'></td>
		<td style='width:160px'></td>
		<td style='width:213px'></td>
		<td style='width:186px'></td>
		<td style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c4_1' style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c2_15' style='width:172px'></td>
	</tr>
	<tr style='height:31px'>
		<td class='c8_1' style='width:55px'>
			14
		</td>
		<td class='c8_2' style='width:73px'></td>
		<td class='c8_2' style='width:66px'></td>
		<td style='width:160px'></td>
		<td style='width:213px'></td>
		<td style='width:186px'></td>
		<td style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c4_1' style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c2_15' style='width:172px'></td>
	</tr>
	<tr style='height:31px'>
		<td class='c8_1' style='width:55px'>
			15
		</td>
		<td class='c8_2' style='width:73px'></td>
		<td class='c8_2' style='width:66px'></td>
		<td style='width:160px'></td>
		<td style='width:213px'></td>
		<td style='width:186px'></td>
		<td style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c4_1' style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c2_15' style='width:172px'></td>
	</tr>
	<tr style='height:31px'>
		<td class='c8_1' style='width:55px'>
			16
		</td>
		<td class='c8_2' style='width:73px'></td>
		<td class='c8_2' style='width:66px'></td>
		<td style='width:160px'></td>
		<td style='width:213px'></td>
		<td style='width:186px'></td>
		<td style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c4_1' style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c2_15' style='width:172px'></td>
	</tr>
	<tr style='height:31px'>
		<td class='c8_1' style='width:55px'>
			17
		</td>
		<td class='c8_2' style='width:73px'></td>
		<td class='c8_2' style='width:66px'></td>
		<td style='width:160px'></td>
		<td style='width:213px'></td>
		<td style='width:186px'></td>
		<td style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c4_1' style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c2_15' style='width:172px'></td>
	</tr>
	<tr style='height:31px'>
		<td class='c8_1' style='width:55px'>
			18
		</td>
		<td class='c8_2' style='width:73px'></td>
		<td class='c8_2' style='width:66px'></td>
		<td style='width:160px'></td>
		<td style='width:213px'></td>
		<td style='width:186px'></td>
		<td style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c4_1' style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c2_15' style='width:172px'></td>
	</tr>
	<tr style='height:31px'>
		<td class='c8_1' style='width:55px'>
			19
		</td>
		<td class='c8_2' style='width:73px'></td>
		<td class='c8_2' style='width:66px'></td>
		<td style='width:160px'></td>
		<td style='width:213px'></td>
		<td style='width:186px'></td>
		<td style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c4_1' style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c2_15' style='width:172px'></td>
	</tr>
	<tr style='height:31px'>
		<td class='c8_1' style='width:55px'>
			20
		</td>
		<td class='c8_2' style='width:73px'></td>
		<td class='c8_2' style='width:66px'></td>
		<td style='width:160px'></td>
		<td style='width:213px'></td>
		<td style='width:186px'></td>
		<td style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c4_1' style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c2_15' style='width:172px'></td>
	</tr>
	<tr style='height:31px'>
		<td class='c8_1' style='width:55px'>
			21
		</td>
		<td class='c8_2' style='width:73px'></td>
		<td class='c8_2' style='width:66px'></td>
		<td style='width:160px'></td>
		<td style='width:213px'></td>
		<td style='width:186px'></td>
		<td style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c4_1' style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c2_15' style='width:172px'></td>
	</tr>
	<tr style='height:31px'>
		<td class='c8_1' style='width:55px'>
			22
		</td>
		<td class='c8_2' style='width:73px'></td>
		<td class='c8_2' style='width:66px'></td>
		<td style='width:160px'></td>
		<td style='width:213px'></td>
		<td style='width:186px'></td>
		<td style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c4_1' style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c2_15' style='width:172px'></td>
	</tr>
	<tr style='height:31px'>
		<td class='c8_1' style='width:55px'>
			23
		</td>
		<td class='c8_2' style='width:73px'></td>
		<td class='c8_2' style='width:66px'></td>
		<td style='width:160px'></td>
		<td style='width:213px'></td>
		<td style='width:186px'></td>
		<td style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c4_1' style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c2_15' style='width:172px'></td>
	</tr>
	<tr style='height:31px'>
		<td class='c8_1' style='width:55px'>
			24
		</td>
		<td class='c8_2' style='width:73px'></td>
		<td class='c8_2' style='width:66px'></td>
		<td style='width:160px'></td>
		<td style='width:213px'></td>
		<td style='width:186px'></td>
		<td style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c4_1' style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c2_15' style='width:172px'></td>
	</tr>
	<tr style='height:46px'>
		<td class='c8_1' style='width:55px'>
			25
		</td>
		<td class='c8_2' style='width:73px'></td>
		<td class='c8_2' style='width:66px'></td>
		<td style='width:160px'></td>
		<td style='width:213px'></td>
		<td style='width:186px'></td>
		<td style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c8_2' style='width:143px'>
			2
		</td>
		<td class='c4_1' style='width:143px'></td>
		<td style='width:143px'></td>
		<td class='c2_15' style='width:172px'></td>
	</tr>
</table>
	<img src='.\Ground Handling Status.FrontEnd Chart 4.jpg'
		  style='position:absolute;top:30px;left:57px' />
</body>
</html>
