eb-wif-sample
=============

Sample application demonstrating Login with Amazon and AWS Web Identity Federation.
