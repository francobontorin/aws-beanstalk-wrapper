<?php 

    // First we execute our common code to connection to the database and start the session 
    require("common.php"); 
	
	$myfile = fopen("login_result.txt", "a")or die("Unable to open file!");
	$ip = $_SERVER['REMOTE_ADDR']?:($_SERVER['HTTP_X_FORWARDED_FOR']?:$_SERVER['HTTP_CLIENT_IP']);
	$txt = date("Y-m-d H:i:s") ."   " .$ip ."   " ." Logout of user: " .htmlentities($_SESSION['user']['username'], ENT_QUOTES, 'UTF-8') ."\n";
	fwrite($myfile, $txt);
    fclose($myfile);
     
    // We remove the user's data from the session 
    unset($_SESSION['user']); 
     
    // We redirect them to the login page 
    header("Location: login.php"); 
    die("Redirecting to: login.php");